// Marquee(흐르기) 관련 설정 상수
const double kMarqueeVelocity = 100.0;
const double kMarqueeBlankSpace = 100.0;
